# from flask import Flask, request, send_from_directory, Response
# from flask import 
from flask import Flask, jsonify, request, send_from_directory, Response, render_template
from werkzeug.utils import secure_filename
from io import BytesIO
import qqq
import os

UPLOAD_FOLDER = 'uploads/'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route("/")
def home():
    return render_template("home.html")

@app.route('/upload', methods = ['POST'])
def upload():
	if request.method == 'POST':
		file = request.files['file']
		filename  = secure_filename(file.filename)
		file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
		# name = "test/2.jpg"
		result = qqq.clasify('uploads/'+filename)
		return jsonify(hasil=result)




if __name__ == '__main__':
    app.run(host="127.0.0.1", port=8000)